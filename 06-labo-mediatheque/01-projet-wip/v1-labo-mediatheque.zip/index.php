<?php
include("./templates/common/header.php");
include("./templates/pdo.php");
include("./templates/common/footer.php");
?>