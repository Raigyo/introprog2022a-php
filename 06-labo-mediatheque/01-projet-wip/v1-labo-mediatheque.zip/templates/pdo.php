<?php
require("function/connection.php");
require("function/sql.php");
require("function/general.php");
require("function/affichage.php");

try {
    $_SESSION["dsn"] = connectDB();
    $_SESSION["increment"] = 0;
    navigation();
} catch (Exception $ex) {
    die("ERREUR FATALE : " . $ex->getMessage() . "Erreur de connexion !");
}
?>
<form action="#" method="get">
    <input type="search" name="terme">
    <input type="submit" name="s" value="Rechercher">
</form>
<div>
    <nav>
        <ul class="pagination">
            <!-- Lien vers la page précédente (désactivé si on se trouve sur la 1ère page) -->
            <li class="page-item <?= ($_SESSION["currentPage"] == 1) ? "disabled" : "" ?>">
                <a href="./?page=<?= $_SESSION["currentPage"] - 1 ?>" class="page-link">Précédente</a>
            </li>
            <?php for ($page = 1; $page <= $_SESSION["page"]; $page++) : ?>
                <!-- Lien vers chacune des pages (activé si on se trouve sur la page correspondante) -->
                <li class="page-item <?= ($_SESSION["currentPage"] == $page) ? "active" : "" ?>">
                    <a href="./?page=<?= $page ?>" class="page-link"><?= $page ?></a>
                </li>
            <?php endfor ?>
            <!-- Lien vers la page suivante (désactivé si on se trouve sur la dernière page) -->
            <li class="page-item <?= ($_SESSION["currentPage"] == $_SESSION["page"]) ? "disabled" : "" ?>">
                <a href="./?page=<?= $_SESSION["currentPage"] + 1 ?>" class="page-link">Suivante</a>
            </li>
        </ul>
    </nav>
</div>
<?php foreach (navigation() as $key => $value) : ?>
    <!-- récupération des ID utile -->
    <?php $filmsID = $value["films_id"]; ?>

    <?php echo "<div id=\"main\" class=\"film " . couleur() . "\">" ?>

    <!-- image -->
    <div class="image">
        <?php echo ("<img src=\"./public/images/" . $value["films_affiche"] . "\">"); ?>
    </div>
    <div class="contenu">
        <!-- titre -->
        <?php echo ("<h2 class=\"titre\">" . $value["films_titre"] . "</h2>"); ?>
        <!-- année -->
        <div class="annee resume">
            <?php echo ("<h3>" . $value["films_annee"] . "</h3>"); ?>
        </div>
        <!-- //genre -->
        <?php echo ("<p>" . genreswitch($filmsID) . " </p>"); ?>
        <!-- //réalisateur -->
        <label>Réalisateur : </label>
        <?php echo ("<p>" . realisateurswitch($filmsID) . " </p>"); ?>
        <!-- //acteurs -->
        <label>Acteurs : </label>
        <?php echo ("<p>" . acteurswitch($filmsID) . " </p>"); ?>
        <!-- //Durée -->
        <label>Durée : </label>
        <?php echo ("<p>" . convertToHoursMins($value["films_duree"], "%2dh%02d") . "</p>"); ?>

        <!-- //resumé -->
        <div class="resume">
            <?php echo ("<p>" . $value["films_resume"] . "</p>"); ?>
        </div>
    </div>
    </div>
<?php endforeach;
?>
<div>
    <nav>
        <ul class="pagination ">
            <!-- Lien vers la page précédente (désactivé si on se trouve sur la 1ère page) -->
            <li class="page-item <?= ($_SESSION["currentPage"] == 1) ? "disabled" : "" ?>">
                <a href="./?page=<?= $_SESSION["currentPage"] - 1 ?>" class="page-link">Précédente</a>
            </li>
            <?php for ($page = 1; $page <= $_SESSION["page"]; $page++) : ?>
                <!-- Lien vers chacune des pages (activé si on se trouve sur la page correspondante) -->
                <li class="page-item <?= ($_SESSION["currentPage"] == $page) ? "active" : "" ?>">
                    <a href="./?page=<?= $page ?>" class="page-link"><?= $page ?></a>
                </li>
            <?php endfor ?>
            <!-- Lien vers la page suivante (désactivé si on se trouve sur la dernière page) -->
            <li class="page-item <?= ($_SESSION["currentPage"] == $_SESSION["page"]) ? "disabled" : "" ?>">
                <a href="./?page=<?= $_SESSION["currentPage"] + 1 ?>" class="page-link">Suivante</a>
            </li>
        </ul>
    </nav>
</div>