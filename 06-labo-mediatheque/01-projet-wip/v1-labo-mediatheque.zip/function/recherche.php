
<?php 
//   verif sur l entré du mot recherché 

if (isset($_GET["s"]) AND $_GET["s"] == "Rechercher")
{
 $_GET["terme"] = htmlspecialchars($_GET["terme"]); //pour sécuriser le formulaire contre les intrusions html
 $terme = $_GET["terme"];

 //$terme = trim($terme); //pour supprimer les espaces dans la requête de l'internaute
 //$terme = strip_tags($terme); //pour supprimer les balises html dans la requête

 if (isset($terme))
 {
    
  $terme = strtolower($terme);
  
  $select_terme = $_SESSION["dsn"] ->prepare("SELECT * FROM films join realisateurs on real_id=films_real_id where films_titre like :recherche or real_nom like :recherche");
   $select_terme->execute(array('recherche'=>"%".$terme."%"));
  
   resultat($select_terme);
   
}
else
{
    $message = "Vous devez entrer votre requete dans la barre de recherche";
}
}
?>


<?php
 function resultat($select_terme){
    while($terme_trouve = $select_terme ->fetch())
  {
   echo $terme_trouve['films_titre'];
  }
  $select_terme->closeCursor();
}
?>