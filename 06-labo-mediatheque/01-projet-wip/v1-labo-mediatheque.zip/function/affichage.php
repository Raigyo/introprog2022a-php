<?php
  //navigation
  function navigation(){
    // On détermine sur quelle page on se trouve
  if(isset($_GET['page']) && !empty($_GET['page'])){
    $_SESSION["currentPage"] = (int) strip_tags($_GET['page']);
  }else{
    $_SESSION["currentPage"] = 1;
  }

  // On détermine le nombre total d'articles
  $sql = 'SELECT COUNT(*) AS nb_films FROM films;';
  
  // On prépare la requête
  $query = $_SESSION["dsn"]->prepare($sql);
  
  // On exécute
  $query->execute();
  
  // On récupère le nombre d'articles
  $result = $query->fetch();
 
  $nbFilms = (int) $result['nb_films'];
  
  // On détermine le nombre d'articles par page
  $parPage = 10;
  
  // On calcule le nombre de pages total
  $_SESSION["page"] = ceil($nbFilms / $parPage);
  
  // Calcul du 1er article de la page
  $premier = ($_SESSION["currentPage"] * $parPage) - $parPage;
  
  $sql = 'SELECT * FROM films LIMIT :premier, :parpage;';
  
  // On prépare la requête
  $query = $_SESSION["dsn"]->prepare($sql);
  
  $query->bindValue(':premier', $premier, PDO::PARAM_INT);
  $query->bindValue(':parpage', $parPage, PDO::PARAM_INT);
  
  // On exécute
  $query->execute();
  
  // On récupère les valeurs dans un tableau associatif
  $films = $query->fetchAll(PDO::FETCH_ASSOC);
  
  return $films;
  
  }
?>